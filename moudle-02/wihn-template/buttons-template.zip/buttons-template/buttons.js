const img = document.getElementById('image1');
const img2 = document.getElementById('image2');

function changeImage1(){
    img.src = 'images/bg1.jpg';
    img2.src = 'images/1.jpg';
}
function changeImage2(){
  img.src = 'images/bg2.jpg';
  img2.src = 'images/2.jpg';
}
function changeImage3(){
  img.src = 'images/bg3.jpg';
  img2.src = 'images/3.jpg';
}